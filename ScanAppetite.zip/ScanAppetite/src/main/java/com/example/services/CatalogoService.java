package com.example.services;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.entitys.Catalogo;
import com.example.entitys.Plato;
import com.example.entitys.Restaurante;
import com.example.repository.CatalogoRepository;
import com.example.repository.PlatoRepository;

@Service
public class CatalogoService {

    @Autowired
    private CatalogoRepository catalogoRepository;

    @Autowired
    private PlatoRepository platoRepository;  

    public List<Catalogo> obtenerCatalogoPorRestauranteYHorario(Restaurante restaurante, LocalDateTime hora) {
     
        LocalDateTime inicio = LocalDateTime.of(hora.toLocalDate(), LocalTime.MIN);
        LocalDateTime fin = LocalDateTime.of(hora.toLocalDate(), LocalTime.MAX);

        return catalogoRepository.findByRestauranteAndHorarioInicioBeforeAndHorarioFinAfter(restaurante, inicio.toLocalTime(), fin.toLocalTime());
    }

    public List<Catalogo> getCatalogo() {
        return catalogoRepository.findAll();
    }

    public Optional<Catalogo> obtenerCatalogoPorRestauranteId(String restauranteId) {
        return catalogoRepository.findByRestauranteId(restauranteId);
    }

    public List<Catalogo> obtenerCatalogosConPlatos() {
        List<Catalogo> catalogos = catalogoRepository.findAll();

        for (Catalogo catalogo : catalogos) {
            catalogo.setPlatos(obtenerPlatosPorCatalogoId(catalogo.getId()));
        }

        return catalogos;
    }

    public List<Plato> obtenerPlatosPorCatalogoId(String catalogoId) {
        return platoRepository.findByCatalogoId(catalogoId);
    }
}
  

    


